curl 'https://search.idigbio.org/v2/search/records/' \
  -H 'Connection: keep-alive' \
  -H 'accept: application/json' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36' \
  -H 'content-type: application/json' \
  -H 'Origin: http://portal.idigbio.org' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --data-binary '{"rq":{"hasImage":true},"sort":[{"genus":"asc"},{"specificepithet":"asc"},{"datecollected":"asc"}],"limit":100,"offset":0}' \
  --compressed

curl 'https://search.idigbio.org/v2/mapping/' \
  -H 'Connection: keep-alive' \
  -H 'Accept: application/json, text/javascript, */*; q=0.01' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36' \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://portal.idigbio.org' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --data-binary '{"rq":{"datecollected":{"type":"exists"}},"type":"auto","threshold":100000}' \
  --compressed

curl 'https://search.idigbio.org/v2/mapping/' \
  -H 'Connection: keep-alive' \
  -H 'Accept: application/json, text/javascript, */*; q=0.01' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36' \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://portal.idigbio.org' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --data-binary '{"rq":{"geopoint":{"type":"geo_bounding_box","top_left":{"lat":35.17380687919771,"lon":-93.51562500000001},"bottom_right":{"lat":23.778642538217404,"lon":-78.04687500000001}}},"type":"auto","threshold":100000}' \
  --compressed

curl 'https://search.idigbio.org/v2/search/records/' \
  -H 'Connection: keep-alive' \
  -H 'accept: application/json' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36' \
  -H 'content-type: application/json' \
  -H 'Origin: http://portal.idigbio.org' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --data-binary '{"rq":{"data":{"type":"fulltext","value":"hadronyche"},"geopoint":{"type":"geo_bounding_box","top_left":{"lat":35.17380687919771,"lon":-93.51562500000001},"bottom_right":{"lat":23.778642538217404,"lon":-78.04687500000001}}},"sort":[{"genus":"asc"},{"specificepithet":"asc"},{"datecollected":"asc"}],"limit":100,"offset":0}' \
  --compressed

curl 'https://search.idigbio.org/v2/mapping/' \
  -H 'Connection: keep-alive' \
  -H 'Accept: application/json, text/javascript, */*; q=0.01' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36' \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://portal.idigbio.org' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --data-binary '{"rq":{"data":{"type":"fulltext","value":"hadronyche"},"geopoint":{"type":"geo_bounding_box","top_left":{"lat":35.17380687919771,"lon":-93.51562500000001},"bottom_right":{"lat":23.778642538217404,"lon":-78.04687500000001}}},"type":"auto","threshold":100000}' \
  --compressed

curl 'https://search.idigbio.org/v2/search/records/' \
  -H 'Connection: keep-alive' \
  -H 'accept: application/json' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36' \
  -H 'content-type: application/json' \
  -H 'Origin: http://portal.idigbio.org' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --data-binary '{"rq":{"genus":"hadronyche"},"sort":[{"genus":"asc"},{"specificepithet":"asc"},{"datecollected":"asc"}],"limit":100,"offset":0}' \
  --compressed

curl 'https://search.idigbio.org/v2/mapping/' \
  -H 'Connection: keep-alive' \
  -H 'Accept: application/json, text/javascript, */*; q=0.01' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36' \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://portal.idigbio.org' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --data-binary '{"rq":{"genus":"hadronyche"},"sort":[{"genus":"asc"},{"specificepithet":"asc"},{"datecollected":"asc"}],"type":"auto","threshold":100000}' \
  --compressed


5 8 12

