burl='beta-search'
purl='search'

#query='{"rq":{"class":"magnoliopsida"},"type":"auto","threshold":100000}'

mkdir results

while read query; do
  echo "$query"

curl 'https://'$burl'.idigbio.org/v2/mapping/' \
  -H 'Connection: keep-alive' \
  -H 'Accept: application/json, text/javascript, */*; q=0.01' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36' \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://beta.idigbio.org' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: http://beta.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --data-binary ''$query'' \
  --compressed >out1.json 2>/dev/null
shortcode1=`cat out1.json | json_reformat | grep shortCode | awk '{print $2}' | sed 's/\"\|\,//g'`
echo "shortcode 1 is: $shortcode1"

curl 'https://'$purl'.idigbio.org/v2/mapping/' \
  -H 'Connection: keep-alive' \
  -H 'Accept: application/json, text/javascript, */*; q=0.01' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36' \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://portal.idigbio.org' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --data-binary ''$query'' \
  --compressed >out1.json 2>/dev/null
shortcode2=`cat out1.json | json_reformat | grep shortCode | awk '{print $2}' | sed 's/\"\|\,//g'`
echo "shortcode 2 is: $shortcode2"
mkdir results/$shortcode2

C1=0
while [  $C1 -lt 2 ]; do
  C2=0
  while [  $C2 -lt 2 ]; do



curl 'https://'$burl'.idigbio.org/v2/mapping/'$shortcode1'/1/'$C1'/'$C2'.png' \
  -H 'Connection: keep-alive' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36' \
  -H 'Accept: image/webp,image/apng,image/*,*/*;q=0.8' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: no-cors' \
  -H 'Sec-Fetch-Dest: image' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Cookie: _ga=GA1.2.2062196221.1584622286; __utmz=193686517.1591125358.12.6.utmcsr=iu.zoom.us|utmccn=(referral)|utmcmd=referral|utmcct=/; __utma=193686517.2062196221.1584622286.1591189174.1591192659.14; _gid=GA1.2.1302611056.1592329777' \
  --compressed >'test1'$C1$C2'.png' 2>/dev/null

curl 'https://'$purl'.idigbio.org/v2/mapping/'$shortcode2'/1/'$C1'/'$C2'.png' \
  -H 'Connection: keep-alive' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36' \
  -H 'Accept: image/webp,image/apng,image/*,*/*;q=0.8' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: no-cors' \
  -H 'Sec-Fetch-Dest: image' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Cookie: _ga=GA1.2.2062196221.1584622286; __utmz=193686517.1591125358.12.6.utmcsr=iu.zoom.us|utmccn=(referral)|utmcmd=referral|utmcct=/; __utma=193686517.2062196221.1584622286.1591189174.1591192659.14; _gid=GA1.2.1302611056.1592329777' \
  --compressed >'test2'$C1$C2'.png' 2>/dev/null

td=`diff 'test1'$C1$C2'.png' 'test2'$C1$C2'.png'`
echo "$query" >results/$shortcode2/query.json
cp 'test1'$C1$C2'.png' results/$shortcode2/'test'$C1$C2'-1.png'
cp 'test2'$C1$C2'.png' results/$shortcode2/'test'$C1$C2'-2.png'
if [ -z "$td" ]
then
  echo "No difference!"
else
  echo "Difference detected!!!"
fi


    let C2=C2+1 
  done
  let C1=C1+1 
done

done <querylist.txt
