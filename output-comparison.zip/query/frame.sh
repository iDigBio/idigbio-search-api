burl='beta-search'
purl='search'

#query='{"rq":{"class":"magnoliopsida"},"type":"auto","threshold":100000}'

mkdir results

while read query; do
  echo "$query"

curl 'https://'$burl'.idigbio.org/v2/mapping/' \
  -H 'Connection: keep-alive' \
  -H 'Accept: application/json, text/javascript, */*; q=0.01' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36' \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://beta.idigbio.org' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: http://beta.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --data-binary ''$query'' \
  --compressed >out1.json 2>/dev/null
shortcode=`cat out1.json | json_reformat | grep shortCode | awk '{print $2}' | sed 's/\"\|\,//g'`
echo "shortcode 1 is: $shortcode"

curl 'https://'$burl'.idigbio.org/v2/mapping/'$shortcode'/1/1/1.png' \
  -H 'Connection: keep-alive' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36' \
  -H 'Accept: image/webp,image/apng,image/*,*/*;q=0.8' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: no-cors' \
  -H 'Sec-Fetch-Dest: image' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Cookie: _ga=GA1.2.2062196221.1584622286; __utmz=193686517.1591125358.12.6.utmcsr=iu.zoom.us|utmccn=(referral)|utmcmd=referral|utmcct=/; __utma=193686517.2062196221.1584622286.1591189174.1591192659.14; _gid=GA1.2.1302611056.1592329777' \
  --compressed >test1.png 2>/dev/null

curl 'https://'$purl'.idigbio.org/v2/mapping/' \
  -H 'Connection: keep-alive' \
  -H 'Accept: application/json, text/javascript, */*; q=0.01' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36' \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://portal.idigbio.org' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --data-binary ''$query'' \
  --compressed >out1.json 2>/dev/null
shortcode=`cat out1.json | json_reformat | grep shortCode | awk '{print $2}' | sed 's/\"\|\,//g'`
echo "shortcode 2 is: $shortcode"
mkdir results/$shortcode
curl 'https://'$purl'.idigbio.org/v2/mapping/'$shortcode'/1/1/1.png' \
  -H 'Connection: keep-alive' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36' \
  -H 'Accept: image/webp,image/apng,image/*,*/*;q=0.8' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: no-cors' \
  -H 'Sec-Fetch-Dest: image' \
  -H 'Referer: http://portal.idigbio.org/portal/search' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Cookie: _ga=GA1.2.2062196221.1584622286; __utmz=193686517.1591125358.12.6.utmcsr=iu.zoom.us|utmccn=(referral)|utmcmd=referral|utmcct=/; __utma=193686517.2062196221.1584622286.1591189174.1591192659.14; _gid=GA1.2.1302611056.1592329777' \
  --compressed >test2.png 2>/dev/null
td=`diff test1.png test2.png`
echo "$query" >results/$shortcode/query.json
cp test1.png results/$shortcode/'test-1.png'
cp test2.png results/$shortcode/'test-2.png'
if [ -z "$td" ]
then
  echo "No difference!"
else
  echo "Difference detected!!!"
fi

done <querylist.txt
